import { useEffect, useState } from 'react';
import styled from 'styled-components';
import Button from './Button';

// Styled component for the orders list
const OrderList = styled.ul`
  list-style: none;
  padding: 0;

  li {
    padding: 15px;
    border-bottom: 1px solid #ccc;
    margin-bottom: 20px;
  }

  h4 {
    margin-bottom: 5px;
  }

  .products {
    margin-left: 20px;
    margin-bottom: 10px;
  }
`;

const OrderItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

// Styled component for the product form
const ProductForm = styled.div`
  margin-top: 20px;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  background-color: #fff;
  justify-content: space-between;
  align-items: center;
  

  label {
    display: block;
    margin-bottom: 10px;
  }

  input {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
  }

  button {
    width: 100%;
  }
`;

function MerchantDashboard() {
  const [orders, setOrders] = useState([]);
  const [newProduct, setNewProduct] = useState({
    productCode: '',
    productName: '',
    imageUrl: '',
    price: ''
  });

  useEffect(() => {
    async function fetchOrders() {
      const response = await fetch('http://localhost:5001/eshop/get-all-orders');
      const data = await response.json();
      setOrders(data);
    }
    fetchOrders();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewProduct({ ...newProduct, [name]: value });
  };

  const handleAddProduct = async () => {
    const response = await fetch('http://localhost:5000/api/products/addProduct', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newProduct)
    });

    if (response.ok) {
      alert('Product added successfully');
      setNewProduct({
        productCode: '',
        productName: '',
        imageUrl: '',
        price: ''
      });
    } else {
      alert('Failed to add product');
    }
  };

  return (
    <div>
      <h2>Merchant Dashboard</h2>
      
      {/* Orders Section */}
      <div>
        <h3>View Orders</h3>
        <OrderList>
          {orders.map(order => (
            <li key={order.orderid}>
            <OrderItem>
              <div>
                <h4>Order ID: {order.id}</h4>
                <h4>User ID: {order.userId}</h4>
                <h4>Products:</h4>
                <div className="products">
                  {order.productCodes.map((code, index) => (
                    <div key={index}>- {code}</div>
                  ))}
                </div>
              </div>
              <Button onClick={() => alert(`Order ${order.id} selected`)}>View Details</Button>
              </OrderItem>
            </li>
          ))}
        </OrderList>
      </div>

      {/* Add Product Section */}
      <ProductForm>
        <h3>Add New Product</h3>
        <label>
          Product Code:
          <input
            type="text"
            name="productCode"
            value={newProduct.productCode}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Product Name:
          <input
            type="text"
            name="productName"
            value={newProduct.productName}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Price:
          <input
            type="number"
            name="price"
            value={newProduct.price}
            onChange={handleInputChange}
          />
        </label>
        <Button onClick={handleAddProduct}>Add Product</Button>
      </ProductForm>
    </div>
  );
}

export default MerchantDashboard;
