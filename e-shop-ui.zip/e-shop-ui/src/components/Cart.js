import { useEffect, useState } from 'react';
import styled from 'styled-components';
import Button from './Button';

// Styled component for the cart items list
const CartList = styled.div`
  padding: 0;
  list-style: none;
`;

const CartItem = styled.div`
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
  padding: 15px;
  display: flex;
  justify-content: space-between;
  align-items: center;

  .item-info {
    flex-grow: 1;
  }

  .item-price {
    font-size: 18px;
    font-weight: bold;
  }
`;

function Cart({ userId }) {
  const [cartItems, setCartItems] = useState([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    async function fetchCartItems() {
      const response = await fetch('http://localhost:5000/api/cart/getcartitems', {
        method: 'GET',
        headers: {
          'UserId': userId
        }
      });
      const data = await response.json();
      setCartItems(data);

      // Calculate the total price
      const totalPrice = data.reduce((sum, item) => sum + item.price, 0);
      setTotal(totalPrice);
    }
    fetchCartItems();
  }, [userId]);

  const handleRemoveItem = async (productCode) => {
    // Call API to remove item from the cart
    await fetch(`http://localhost:5000/api/cart/removeitem/${productCode}`, { method: 'DELETE' });

    // Update the cart items after removal
    const updatedCart = cartItems.filter(item => item.productCode !== productCode);
    setCartItems(updatedCart);

    // Recalculate total price
    const newTotal = updatedCart.reduce((sum, item) => sum + item.price, 0);
    setTotal(newTotal);
  };

  const handleCheckout = () => {
    // Redirect to payment gateway URL
    window.location.href = 'https://your-payment-gateway-url.com';
  };

  return (
    <div>
      <h2>Your Cart</h2>
      <CartList>
        {cartItems.map(item => (
          <CartItem key={item.productCode}>
            <div className="item-info">
              <h3>{item.productName}</h3>
              <div className="item-price">${item.price}</div>
            </div>
            <Button onClick={() => handleRemoveItem(item.productCode)}>Remove</Button>
          </CartItem>
        ))}
      </CartList>
      <div>
        <h3>Total: ${total}</h3>
        <Button onClick={handleCheckout}>Checkout</Button>
      </div>
    </div>
  );
}

export default Cart;
