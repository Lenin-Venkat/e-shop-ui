import styled from 'styled-components';

const Button = styled.button`
  background-color: ${(props) => props.bgColor || "##277777"};
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  
  &:hover {
    background-color: ${(props) => props.hoverColor || "#0056b3"};
  }
`;

export default Button;
