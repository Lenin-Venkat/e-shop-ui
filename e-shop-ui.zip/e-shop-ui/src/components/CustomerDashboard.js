import { useEffect, useState } from 'react';
import styled from 'styled-components';
import Button from './Button';

// Styled component for the product list
const ProductList = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  padding: 0;
  list-style: none;
`;

const ProductItem = styled.div`
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  width: calc(33% - 20px);
  padding: 15px;
  text-align: center;

  img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
  }

  .product-info {
    margin: 10px 0;
  }

  .price {
    font-size: 18px;
    font-weight: bold;
  }
`;

function CustomerDashboard() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    async function fetchProducts() {
      const response = await fetch('http://localhost:5000/api/products/get-all-products');
      const data = await response.json();
      setProducts(data);
    }
    fetchProducts();
  }, []);

  const handleAddToCart = (productCode) => {
    // Add to cart logic here
    alert(`Added product ${productCode} to cart`);
  };

  return (
    <div>
      <h2>Available Products</h2>
      <ProductList>
        {products.map(product => (
          <ProductItem key={product.productCode}>
            <img src={product.imageUrl} alt={product.productName} />
            <div className="product-info">
              <h3>{product.productName}</h3>
              <div className="price">${product.price}</div>
            </div>
            <Button onClick={() => handleAddToCart(product.productCode)}>Add to Cart</Button>
          </ProductItem>
        ))}
      </ProductList>
    </div>
  );
}

export default CustomerDashboard;
