import { useState } from 'react';
// import { login } from '../services/authService';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    // const result = await login({ email, password });
    if (true) {
      // if (result.success) {
      // Redirect based on role
      const role = 'merchant';
      // const role = result.data.role;
      window.location.href = role === 'merchant' ? '/merchant' : '/customer';
    } else {
      alert('Unauthorized');
      // alert(result.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email"
      />
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
      />
      <button type="submit">Login</button>
    </form>
  );
}

export default Login;
