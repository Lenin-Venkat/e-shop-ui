import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import styled, { createGlobalStyle } from 'styled-components';
import Login from './components/Login';
import MerchantDashboard from './components/MerchantDashboard';
import CustomerDashboard from './components/CustomerDashboard';
import Cart from './components/Cart';


// Global styles for the whole app
const GlobalStyle = createGlobalStyle`
  body {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
  }
  a {
    text-decoration: none;
    color: #007BFF;
  }
  h1, h2, h3, h4 {
    color: #333;
  }
  button {
    background-color: #277777;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    &:hover {
      background-color: #0056b3;
    }
  }
  input {
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
    width: 100%;
  }
`;

// Reusable container for the main layout
const Container = styled.div`
  max-width: 1200px;
  margin: 40px auto; /* Added margin to give space between header and content */
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
`;

// Header component
const Header = styled.header`
  background-color: #277777;
  color: white;
  padding: 20px;
  text-align: center;
  font-size: 24px;
  font-weight: bold;
`;

// Footer component
const Footer = styled.footer`
  position: fixed;
  bottom: 0;
  width: 100%;
  background-color: #277777;
  color: white;
  padding: 10px;
  text-align: left;
  display: flex;
  justify-content: space-between;
  font-size: 14px;
`;

function App() {
  return (
    <Router>
      <GlobalStyle />
      <Header>E-Shop</Header>
      <Container>
      <Routes>
        <Route exact path='/' element={<Login/>} />
        <Route path="/merchant" element={<MerchantDashboard/>} />
        <Route path="/customer" element={<CustomerDashboard/>} />
        <Route path="/cart" element={<Cart/>} />  
      </Routes>
      </Container>
      <Footer>
        <span>© 2024 E-Shop</span>
        <span>Version 1.0.0</span>
      </Footer>
    </Router>
  );
}

export default App;
